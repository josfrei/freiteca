import { ListaPeliculas } from "../interfaces/peliculas-interfaces";
import { ListaCamara } from '../../../../camaras-galicia/src/app/camaras/interfaces/camaras-interf.interfaces';

export class PeliculaMapper {



}
